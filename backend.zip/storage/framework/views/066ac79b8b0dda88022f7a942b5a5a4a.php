<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Laravel Pagination Demo</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>

<body>
    <div class="container mt-5">

        <h5>Realisasi Per Jenis Kegiatan</h5>

        <table class="table table-bordered mb-5">
            <thead>
                <tr class="table-success">
                    <th>#</th>
                    <th>Kode</th>
                    <th>Kegiatan</th>
                    <th>Unit</th>
                    <th>Pagu</th>
                    <th>Realisasi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $realisasiKegiatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kegiatan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="lh-1"><?php echo e($loop->iteration); ?></td>
                    <td class="lh-1"><?php echo e($kegiatan->kode); ?></td>
                    <td class="lh-1"><?php echo e($kegiatan->name); ?></td>
                    <td class="lh-1"><?php echo e($kegiatan->group->name); ?></td>
                    <td class="lh-1"><?php echo e($kegiatan->pagu); ?></td>
                    <td class="lh-1"><?php echo e($kegiatan->realisasi_saat_ini); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>

        <h5>Realisasi Per Jenis Belanja</h5>
        <table class="table table-bordered mb-5">
            <thead>
                <tr class="table-success">
                    <th>#</th>
                    <th>Kegiatan</th>
                    <th>Pagu</th>
                    <th>Realisasi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $realisasiBelanja; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $belanja): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="lh-1"><?php echo e($loop->iteration); ?></td>
                    <td class="lh-1"><?php echo e($belanja->name); ?></td>
                    <td class="lh-1"><?php echo e($belanja->pagu); ?></td>
                    <td class="lh-1"><?php echo e($belanja->realisasi_saat_ini); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>

        <h5>Indikator Kinerja Utama</h5>
        <table class="table table-bordered mb-5">
            <thead>
                <tr class="table-success">
                    <th>#</th>
                    <th>Indikator</th>
                    <th>Target</th>
                    <th>Realisasi</th>
                    <th>Analisa</th>
                    <th>Kendala</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $realisasiIKU; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $iku): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="lh-1"><?php echo e($loop->iteration); ?></td>
                    <td class="lh-1"><?php echo e($iku->name); ?></td>
                    <td class="lh-1"><?php echo e($iku->target); ?></td>
                    <td class="lh-1"><?php echo $iku->realisasi->realisasi ?? '-'; ?></td>
                    <td class="lh-sm"><?php echo nl2br(e($iku->realisasi->analisa ?? '')); ?> </td>
                    <td class="lh-1"><?php echo $iku->realisasi->kendala ?? ''; ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>


        <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <h5>Indikator Kinerja Kegiatan <?php echo e($group->name); ?></h5>
        <table class="table table-bordered mb-5">
            <thead>
                <tr class="table-success">
                    <th>#</th>
                    <th>Indikator</th>
                    <th>Target</th>
                    <th>Realisasi</th>
                    <th>Analisa</th>
                    <th>Kendala</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $group->ikk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ikk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="lh-1"><?php echo e($loop->iteration); ?></td>
                    <td class="lh-1"><?php echo e($ikk->name); ?></td>
                    <td class="lh-1"><?php echo e($ikk->target); ?></td>
                    <td class="lh-1"><?php echo nl2br(e($ikk->realisasi->realisasi ?? '-')); ?></td>
                    <td class="lh-sm"><?php echo nl2br(e($ikk->realisasi->analisa ?? '')); ?> </td>
                    <td class="lh-1"><?php echo nl2br(e($ikk->realisasi->kendala ?? '')); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
</body>

</html><?php /**PATH C:\LUCKY\butri\backend\resources\views/laporan/view.blade.php ENDPATH**/ ?>