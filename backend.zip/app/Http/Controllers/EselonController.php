<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class EselonController extends Controller
{
    //
}
